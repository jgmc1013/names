@extends('layout')

@section('title','Names')

@section('content')
<h1>Name</h1>
@endsection
