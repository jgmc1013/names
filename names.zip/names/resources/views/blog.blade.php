@extends('layout')

@section('title','Blog')

@section('content')
<h1>blog</h1>
@endsection
