@extends('layout')

@section('title','Contact')

@section('content')
<h1>Contact</h1>
@endsection
